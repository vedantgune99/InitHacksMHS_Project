emailID = 'mentalhealthapp2023@gmail.com'
password = "ikhn nsbc rtek efev"
SECRET_KEY = 'VVG_APP123'